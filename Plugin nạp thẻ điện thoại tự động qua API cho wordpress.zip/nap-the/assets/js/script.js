jQuery(document).ready(function($) {
    $('#nap_the_form').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();

        $.ajax({
            url: nap_the_ajax.ajaxurl,
            method: 'POST',
            data: {
                action: 'nap_the_process',
                ...formData
            },
            success: function(response) {
                $('#response_message').text(response.data.msg).addClass(response.success ? 'success' : 'error');
            },
            error: function() {
                $('#response_message').text('Có lỗi xảy ra.').addClass('error');
            }
        });
    });
});
