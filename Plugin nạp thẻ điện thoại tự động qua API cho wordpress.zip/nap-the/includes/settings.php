<?php
if (!defined('ABSPATH')) {
    exit;
}

// Hàm tạo trang cài đặt trong Admin
function nap_the_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php _e('Cài Đặt Nạp Thẻ', 'nap-the'); ?></h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('nap_the_settings_group');
            do_settings_sections('nap_the_settings_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('Partner ID', 'nap-the'); ?></th>
                    <td><input type="text" name="nap_the_partner_id" value="<?php echo esc_attr(get_option('nap_the_partner_id')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Partner Key', 'nap-the'); ?></th>
                    <td><input type="text" name="nap_the_partner_key" value="<?php echo esc_attr(get_option('nap_the_partner_key')); ?>" /></td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('API URL', 'nap-the'); ?></th>
                    <td><input type="text" name="nap_the_api_url" value="<?php echo esc_attr(get_option('nap_the_api_url')); ?>" /></td>
                </tr>
            </table>

            <?php submit_button(); ?>
        </form>
    </div>
<?php }

// Đăng ký các thiết lập của plugin
function nap_the_register_settings() {
    register_setting('nap_the_settings_group', 'nap_the_partner_id');
    register_setting('nap_the_settings_group', 'nap_the_partner_key');
    register_setting('nap_the_settings_group', 'nap_the_api_url');
}
add_action('admin_init', 'nap_the_register_settings');

// Tạo mục cài đặt trong menu Admin
function nap_the_add_admin_menu() {
    add_menu_page(
        __('Nạp Thẻ', 'nap-the'), 
        __('Nạp Thẻ', 'nap-the'), 
        'manage_options', 
        'nap_the_settings', 
        'nap_the_settings_page', 
        'dashicons-admin-settings', 
        81
    );
}
add_action('admin_menu', 'nap_the_add_admin_menu');
