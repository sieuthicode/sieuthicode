<?php
if (!defined('ABSPATH')) {
    exit;
}

// Hàm xử lý nạp thẻ qua API
function nap_the_process_card() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_send_json_error(['msg' => __('Yêu cầu không hợp lệ.', 'nap-the')]);
    }

    // Lấy thông tin từ form
    $username = sanitize_text_field($_POST['user']);
    $type_the = sanitize_text_field($_POST['loaithe']);
    $menh_gia = sanitize_text_field($_POST['menhgia']);
    $ma_the = sanitize_text_field($_POST['mathe']);
    $seri_the = sanitize_text_field($_POST['serithe']);
    $captcha_input = intval(sanitize_text_field($_POST['captcha']));
    $request_id = 'X10-' . wp_rand(1000000000, 9999999999); // Random request_id
    $ip = $_SERVER['REMOTE_ADDR'];

    // Kiểm tra thông tin đầu vào
    if (empty($username) || empty($type_the) || empty($menh_gia) || empty($ma_the) || empty($seri_the)) {
        wp_send_json_error(['msg' => __('Vui lòng nhập đầy đủ thông tin.', 'nap-the')]);
    }
    if (!ctype_digit($ma_the) || !ctype_digit($seri_the)) {
        wp_send_json_error(['msg' => __('Mã thẻ và Seri phải là số.', 'nap-the')]);
    }

    // Kiểm tra captcha
    session_start();
    if ($captcha_input !== $_SESSION['captcha_result']) {
        wp_send_json_error(['msg' => __('Kết quả captcha không đúng, vui lòng thử lại.', 'nap-the')]);
    }

    // Kiểm tra số lần gửi thẻ từ địa chỉ IP
    $ip_log = get_option('nap_the_ip_log', []);
    if (!isset($ip_log[$ip])) {
        $ip_log[$ip] = 1;
    } else {
        if ($ip_log[$ip] >= 4) {
            wp_send_json_error(['msg' => __('Bạn đã gửi quá nhiều thẻ từ địa chỉ IP này, liên hệ quản trị viên.', 'nap-the')]);
        } else {
            $ip_log[$ip]++;
        }
    }
    update_option('nap_the_ip_log', $ip_log);

    // Gửi yêu cầu nạp thẻ qua API
    $partner_id = get_option('nap_the_partner_id');
    $partner_key = get_option('nap_the_partner_key');
    $gach_the = get_option('nap_the_api_url');
    $signature = md5($partner_key . $ma_the . $seri_the);
    $url = $gach_the . "/chargingws/v2";
    $args = [
        'body' => [
            'sign' => $signature,
            'telco' => $type_the,
            'code' => $ma_the,
            'serial' => $seri_the,
            'amount' => $menh_gia,
            'request_id' => $request_id,
            'partner_id' => $partner_id,
            'command' => 'charging',
        ],
    ];

    $response = wp_remote_post($url, $args);
    if (is_wp_error($response)) {
        wp_send_json_error(['msg' => __('Có lỗi khi kết nối tới API.', 'nap-the')]);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    if ($body['status'] === 99) {
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'nap_the_history',
            [
                'ip' => $ip,
                'code' => $request_id,
                'seri' => $seri_the,
                'pin' => $ma_the,
                'loaithe' => $type_the,
                'menhgia' => $menh_gia,
                'thucnhan' => 0,
                'status' => 'xuly',
                'time' => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s']
        );

        wp_send_json_success(['msg' => __('Nạp thẻ thành công, vật phẩm sẽ vào khi thẻ đúng.', 'nap-the')]);
    } else {
        wp_send_json_error(['msg' => $body['message']]);
    }
}
add_action('wp_ajax_nap_the_process', 'nap_the_process_card');
add_action('wp_ajax_nopriv_nap_the_process', 'nap_the_process_card');
