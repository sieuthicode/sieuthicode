<div id="nap-the-wrapper">
    <h2 class="nap-the-title">Nạp Tiền Qua Thẻ Cào</h2>
    <form id="napTheForm" class="nap-the-form">
        <?php wp_nonce_field('nap_the_action', 'nonce'); ?>
        
        <div class="form-group">
            <label for="user">Tên Người Dùng:</label>
            <input type="text" name="user" id="user" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="loaithe">Loại Thẻ:</label>
            <select name="loaithe" id="loaithe" class="form-control" required>
                <option value="VIETTEL">Viettel</option>
                <option value="VINAPHONE">Vinaphone</option>
                <option value="MOBIFONE">Mobifone</option>
            </select>
        </div>

        <div class="form-group">
            <label for="menhgia">Mệnh Giá:</label>
            <select name="menhgia" id="menhgia" class="form-control" required>
                <option value="50000">50.000</option>
                <option value="100000">100.000</option>
            </select>
        </div>

        <div class="form-group">
            <label for="mathe">Mã Thẻ:</label>
            <input type="text" name="mathe" id="mathe" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="serithe">Seri Thẻ:</label>
            <input type="text" name="serithe" id="serithe" class="form-control" required>
        </div>

        <button type="submit" class="submit-btn">Nạp Thẻ</button>
    </form>
    <div id="nap-the-result"></div>
</div>
<script src="<?php echo NAP_THE_URL . 'assets/js/script.js'; ?>"></script>
